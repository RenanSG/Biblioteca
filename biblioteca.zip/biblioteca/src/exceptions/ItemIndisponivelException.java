package exceptions;

public class ItemIndisponivelException extends Exception {
    public ItemIndisponivelException(String mensagem) {
        super(mensagem);
    }
}