package model;

public record Autor(String nome, String nacionalidade, int idade) {}

