package model;

public interface Catalogavel {
    boolean contemTermo(String termo);
}
