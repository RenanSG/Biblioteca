package model;

public record Categoria(String genero, String estilo, String tema) {


}

